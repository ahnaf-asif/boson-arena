@extends('Admin.layout.admin')

@section('title')

@endsection

@section('heading')

@endsection

@section('content')

@endsection
