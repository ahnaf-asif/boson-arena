<footer class="main-footer">
    <strong>Copyright &copy; 2021 <a href="https://www.facebook.com/asifthen00b/">Ahnaf Shahriar Asif</a>.</strong>
    All rights reserved.

</footer>
