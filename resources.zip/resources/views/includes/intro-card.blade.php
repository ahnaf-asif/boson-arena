<div class="card home-card">

    <div class="card-body">
        <h3 class="card-title text-center">Here is the Fest Name</h3>
        <p class="card-text">
            Lorem ipsum dolor sit amet, consectetur adipisicing elit. Deleniti earum eum ex hic illum impedit labore perspiciatis repellendus vel. Alias aliquid amet consequatur cumque eligendi facere inventore laborum omnis quis? See event details <a href="#">Here</a>.
        </p>
    </div>
</div>
