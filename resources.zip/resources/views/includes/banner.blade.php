<img src="{{asset('images/jn_islam.jpg')}}" style="width: 100%;height: auto;">
