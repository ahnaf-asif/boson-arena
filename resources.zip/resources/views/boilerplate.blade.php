@extends('layouts.app')

@section('title')

@endsection

@section('custom-css')

@endsection


@section('content')



    @include('includes.toast-testing')
@endsection



@section('custom-js')

@endsection
